from django.apps import AppConfig


class App2012MajusIdegenConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_2012_majus_idegen'
